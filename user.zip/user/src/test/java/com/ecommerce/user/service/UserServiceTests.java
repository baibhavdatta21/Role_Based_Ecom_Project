package com.ecommerce.user.service;

import com.ecommerce.user.dto.AddressDTO;
import com.ecommerce.user.dto.UserRequest;
import com.ecommerce.user.dto.UserResponse;
import com.ecommerce.user.model.Address;
import com.ecommerce.user.model.User;
import com.ecommerce.user.model.UserRole;
import com.ecommerce.user.repository.UserRepository;
import com.ecommerce.user.security.JwtUtil;
import com.ecommerce.user.service.UserService;
import jakarta.servlet.http.HttpServletRequest;
import org.junit.jupiter.api.*;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.core.Authentication;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class UserServiceTests {
    @Mock
    private UserRepository userRepository;

    @Mock
    private AuthenticationManager authManager;

    @Mock
    private JwtUtil jwtUtil;

    @Mock
    private HttpServletRequest request;

    @InjectMocks
    private UserService userService;

    private User user;
    private UserRequest userRequest;

    @BeforeEach
    void setup() {
        ReflectionTestUtils.setField(userService, "authManager", authManager);
        ReflectionTestUtils.setField(userService, "jwtUtil", jwtUtil);

        Address address = new Address(
                "street",
                "city",
                "state",
                "country",
                "700001"
        );

        UserRole role = new UserRole("CUSTOMER");

        user = new User();
        user.setId(1);
        user.setFirstName("Leo");
        user.setLastName("Messi");
        user.setEmail("goat@gmail.com");
        user.setPassword("wc2022");
        user.setPhone("9999999999");
        user.setAddress(address);
        user.setRole(List.of(role));

        AddressDTO addressDTO = new AddressDTO();
        addressDTO.setStreet("street");
        addressDTO.setCity("city");
        addressDTO.setState("state");
        addressDTO.setCountry("country");
        addressDTO.setZipcode("700001");

        userRequest = new UserRequest();
        userRequest.setFirstName("Leo");
        userRequest.setLastName("Messi");
        userRequest.setEmail("goat@gmail.com");
        userRequest.setPassword("wc2022");
        userRequest.setPhone("9999999999");
        userRequest.setRole("CUSTOMER");
        userRequest.setAddress(addressDTO);
    }

    @Test
    @Order(1)
    void signupSuccess() {
        when(userRepository.save(any(User.class)))
                .thenReturn(user);
        ResponseEntity<?> response = userService.signup(userRequest);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        verify(userRepository, times(1))
                .save(any(User.class));
    }
    @Test
    @Order(2)
    void signupFailureInvalidRole() {
        userRequest.setRole("ADMIN");
        ResponseEntity<?> response = userService.signup(userRequest);
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
    }
    @Test
    @Order(3)
    void signupAdminSuccess(){
        userRequest.setRole("ADMIN");
        ResponseEntity<?> response = userService.signUpAdmin(userRequest);
        assertEquals(HttpStatus.OK, response.getStatusCode());
        verify(userRepository, times(1)).save(any(User.class));
    }
    @Test
    @Order(4)
    void addUser_ShouldReturnJwt_WhenAuthenticated() {

        Authentication authentication = mock(Authentication.class);

        when(userRepository.findByEmail("goat@gmail.com"))
                .thenReturn(Optional.of(user));

        when(authManager.authenticate(any())) .thenReturn(authentication);

        when(authentication.isAuthenticated())
                .thenReturn(true);

        when(jwtUtil.generateToken(any()))
                .thenReturn("jwt-token");

        ResponseEntity<?> response =
                userService.addUser(userRequest);

        assertEquals(HttpStatus.OK, response.getStatusCode());

        assertEquals("jwt-token", response.getBody());
    }

    @Test
    @Order(5)
    void getAllUsersSuccess(){
        when(userRepository.findAll()).thenReturn(List.of(user));
        List<UserResponse> response=userService.getAllUsers();
        assertEquals(1,response.size());
        assertEquals("goat@gmail.com", response.get(0).getEmail());
    }
    @Test
    @Order(6)
    void getUserSuccess(){
        when(userRepository.findById("1")).thenReturn(Optional.of(user));
        UserResponse response = userService.getUser("1");
        assertEquals("Leo", response.getFirstName());
        verify(userRepository, times(1)).findById("1");
    }
    @Test
    @Order(7)
    void putUserSuccess(){
        when(userRepository.findById("1")).thenReturn(Optional.of(user));
        when(request.getHeader("Authorization")).thenReturn("Bearer token");
        when(jwtUtil.hasRole("token","ADMIN")).thenReturn(true);
        when(userRepository.save(any(User.class))).thenReturn(user);
        ResponseEntity<?> response =
                userService.putUser("1", userRequest, request);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        verify(userRepository, times(1)).save(any(User.class));
    }
    @Test
    @Order(8)
    void deleteUserSuccess(){
        when(userRepository.findById("1")).thenReturn(Optional.of(user));
        when(request.getHeader("Authorization")).thenReturn("Bearer token");
        when(jwtUtil.hasRole("token","ADMIN")).thenReturn(true);
//        when(userRepository.delete(any(User.class)));
        ResponseEntity<?> response =
                userService.deleteUser("1", request);

        assertEquals(HttpStatus.OK, response.getStatusCode());
    }
    @Test
    @Order(9)
    void deleteUser_ShouldFail_WhenUnauthorized() {

        when(userRepository.findById("1"))
                .thenReturn(Optional.of(user));

        when(request.getHeader("Authorization"))
                .thenReturn("Bearer token");

        when(jwtUtil.hasRole("token", "ADMIN"))
                .thenReturn(false);

        when(jwtUtil.extractUserName("token"))
                .thenReturn("another@gmail.com");

        ResponseEntity<?> response =
                userService.deleteUser("1", request);

        assertEquals(HttpStatus.BAD_REQUEST,
                response.getStatusCode());
    }

}
